const { post } = require("../../routes/users");


function addToCart(productId) {

    $.ajax({
        url: "/add-cart/" + productId,
        method: 'get',
        success: (response) => {
            if (response.status) {
                let count = $('#cart-count').html()
                count = parseInt(count) + 1
                $("#cart-count").html(count);
                location.reload();
            }
        }
    })
}

function changeQuantity(cartId, productId, userId, count) {
    let quantity = parseInt(document.getElementById(productId).innerHTML);
    count = parseInt(count);
    $.ajax({
        url: '/change-quantity',
        data: {
            user: userId,
            cart: cartId,
            product: productId,
            count: count,
            quantity: quantity
        },
        method: 'post',
        success: (response) => {
            if (response.removeProduct) {
                alert('Product is Removed')
                location.reload();
            } else {
                let newQuantity = quantity + count
                document.getElementById(productId).innerHTML = newQuantity;
                location.reload();

            }
        }
    })
}

function deleteProduct(cartId, productId) {
    var question = confirm('Product will be Removed')
    if (question == true) {
        $.ajax({
            url: 'delete-product',
            data: {
                cart: cartId,
                product: productId
            },
            method: 'post',
            success: (response) => {
                if (response.removeProduct) {
                    alert('Product is Removed')
                    location.reload();
                }
            }

        })
    }
}
