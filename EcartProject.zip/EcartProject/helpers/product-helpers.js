var db = require('../config/connection')
var collections = require('../config/collections')
var objectId = require('mongodb').ObjectID
const { response } = require('express')

module.exports = {
    addProduct: (product, callback) => {
        product.prize=parseInt(product.prize)
        db.get().collection(collections.PRODUCT_COLLECTIONS).insertOne(product).then((data) => {
            callback(data.ops[0]._id)

        })

    },
    addStatus: (status) => {
        return new Promise((resolve, reject) => {
            const colid = status
            db.get().collection(collections.PRODUCT_COLLECTIONS).updateOne({ _id: objectId(colid) }, 
            { $set: { "status": "0"} }).then((response) => {
                resolve(response)
            })
        })

    },
    getAllProducts: () => {
        return new Promise(async(resolve, reject) => {
            let products = await db.get().collection(collections.PRODUCT_COLLECTIONS).find({ "status": "0" }).toArray()
            resolve(products)
        })
    },
    deleteProduct: (productId) => {
        return new Promise((resolve, reject) => {
            db.get().collection(collections.PRODUCT_COLLECTIONS).updateOne({ _id: objectId(productId) }, { $set: { "status": "1" } }).then((response) => {
                resolve(response)
            })
        })
    },
    getProductDetails: (productId) => {
        return new Promise((resolve, reject) => {
            db.get().collection(collections.PRODUCT_COLLECTIONS).findOne({ _id: objectId(productId) }).then((product) => {
                resolve(product)
            })
        })
    },
    updateProduct: (productId, product) => {
        return new Promise((resolve, reject) => {
            db.get().collection(collections.PRODUCT_COLLECTIONS).updateOne({ _id: objectId(productId) }, {
                $set: {
                    name: product.name,
                    category: product.category,
                    description: product.description,
                    prize: product.prize,
                    status: "0"
                }
            }).then((response) => {
                resolve()
            })
        })
    },
    


}