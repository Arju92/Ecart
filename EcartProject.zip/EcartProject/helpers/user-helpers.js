var db = require('../config/connection')
var collections = require('../config/collections')
const bcrypt = require('bcrypt')
var objectId = require('mongodb').ObjectID
const { response } = require('express')
const { PRODUCT_COLLECTIONS } = require('../config/collections')

module.exports = {
    doSignup: (userData) => {
        return new Promise(async (resolve, reject) => {
            userData.Password = await bcrypt.hash(userData.Password, 10)
            db.get().collection(collections.USER_COLLECTIONS).insertOne(userData).then((data) => {
                resolve(data.ops[0])
            })

        })

    },
    doSignin: (signinData) => {
        return new Promise(async (resolve, reject) => {
            let loginStatus = false
            let response = {}
            let user = await db.get().collection(collections.USER_COLLECTIONS).findOne({ Email: signinData.Email })
            if (user) {
                bcrypt.compare(signinData.Password, user.Password).then((status) => {
                    if (status) {
                        response.user = user
                        response.status = true
                        resolve(response)
                    } else {
                        resolve({ status: false })
                    }
                })
            } else {
                resolve({ status: false })
            }
        })
    },
    addtoCart: (productId, userId) => {
        let productObj = {
            item: objectId(productId),
            quantity: 1
        }
        return new Promise(async (resolve, reject) => {
            let userCart = await db.get().collection(collections.CART_COLLECTIONS).
                findOne({ orderStatus: "1" })
            if (userCart) {
                let productExist = userCart.products.findIndex(product => product.item == productId)
                if (productExist != -1) {
                    console.log(productId);
                    db.get().collection(collections.CART_COLLECTIONS).
                        updateOne({ 'products.item': objectId(productId), orderStatus: '1' }, {
                            $inc: {
                                'products.$.quantity': 1
                            }
                        }).then(() => {
                            resolve()
                        })
                } else {
                    db.get().collection(collections.CART_COLLECTIONS).updateOne({ user: objectId(userId) }, {
                        $push: {
                            products: productObj
                        }

                    }).then((response) => {
                        resolve()
                    })
                }
            } else {
                let cartObj = {
                    user: objectId(userId),
                    products: [productObj],

                    orderStatus: "1"
                }
                db.get().collection(collections.CART_COLLECTIONS).insertOne(cartObj).then((response) => {
                    resolve()
                })
            }


        })

    },
    getCartProduct: (userId) => {
        return new Promise(async (resolve, reject) => {

            let cartProduct = await db.get().collection(collections.CART_COLLECTIONS).aggregate([
                {
                    $match: { user: objectId(userId) }
                },
                {
                    $unwind: '$products'
                },
                {
                    $project: {
                        item: '$products.item',
                        quantity: '$products.quantity'
                    }
                },
                {
                    $lookup: {
                        from: collections.PRODUCT_COLLECTIONS,
                        localField: 'item',
                        foreignField: '_id',
                        as: 'productItems'
                    }
                },
                {
                    $project: {
                        item: 1,
                        quantity: 1,
                        productItems: {
                            $arrayElemAt: ['$productItems', 0]
                        }

                    }
                },
                {
                    $project: {
                        item: 1,
                        quantity: 1,
                        productItems: 1,
                        subTotal: { $multiply: ['$quantity', '$productItems.prize'] }
                    }
                }
            ]).toArray()

            console.log(cartProduct);
            resolve(cartProduct)
        })
    },
    getCartCount: (userId) => {

        return new Promise(async (resolve, reject) => {
            let count = 0
            let userCart = await db.get().collection(collections.CART_COLLECTIONS)
                .findOne({ orderStatus: "1" })
            if (userCart) {
                count = userCart.products.length
            }
            resolve(count)
        })
    },
    deleteProduct: (details) => {
        return new Promise(async (resolve, reject) => {
            db.get().collection(collections.CART_COLLECTIONS)
                .updateOne({ _id: objectId(details.cart), orderStatus: "1" },
                    {
                        $pull: {
                            products: { item: objectId(details.product) }
                        }
                    }).then((response) => {
                        resolve({ removeProduct: true })
                    })

                })
        },
            changeQuantity: (details) => {

                details.count = parseInt(details.count)
                details.quantity = parseInt(details.quantity)
                return new Promise(async (resolve, reject) => {
                    if (details.count == -1 && details.quantity == 1) {
                        db.get().collection(collections.CART_COLLECTIONS)
                            .updateOne({ _id: objectId(details.cart), orderStatus: "1" },
                                {
                                    $pull: {
                                        products: { item: objectId(details.product) }
                                    }
                                }).then((response) => {
                                    resolve({ removeProduct: true })
                                })

                    } else {
                        db.get().collection(collections.CART_COLLECTIONS)
                            .updateOne({
                                _id: objectId(details.cart),
                                'products.item': objectId(details.product),
                                orderStatus: "1"
                            },
                                {
                                    $inc: {
                                        'products.$.quantity': details.count
                                    }
                                }).then((response) => {
                                    resolve(true)
                                })
                    }
                })
            },
            getTotal: (userId) => {
                return new Promise(async (resolve, reject) => {

                    let total = await db.get().collection(collections.CART_COLLECTIONS).aggregate([
                        {
                            $match: { user: objectId(userId) }
                        },
                        {
                            $unwind: '$products'
                        },
                        {
                            $project: {
                                item: '$products.item',
                                quantity: '$products.quantity'
                            }
                        },
                        {
                            $lookup: {
                                from: collections.PRODUCT_COLLECTIONS,
                                localField: 'item',
                                foreignField: '_id',
                                as: 'productItems'
                            }
                        },
                        {
                            $project: {
                                item: 1,
                                quantity: 1,
                                productItems: {
                                    $arrayElemAt: ['$productItems', 0]
                                }

                            }
                        },
                        {
                            $group: {
                                _id: null,
                                total: { $sum: { $multiply: ['$quantity', '$productItems.prize'] } }
                            }
                        }
                    ]).toArray()
                    resolve(total[0].total)
                })
            }
    

}