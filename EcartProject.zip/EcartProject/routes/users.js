const { response } = require('express');
var express = require('express');
var router = express.Router();
var productHelper = require('../helpers/product-helpers')
var userHelper = require('../helpers/user-helpers')

const verifyLogin = (req, res, next) => {
    if (req.session.loggedIn) {
        next()
    } else {
        console.log("check");
        res.render('users/signin')
    }
}

/* GET home page. */
router.get('/', async function (req, res, next) {
    let user = req.session.user
    let cartCount = null
    if (user) {
        cartCount = await userHelper.getCartCount(req.session.user._id)
    }
    productHelper.getAllProducts().then((products) => {
        res.render('users/show-products', { products, user, cartCount });
    })
});
router.get('/signin', (req, res, next) => {
    console.log(req.session.loggedIn);
    if (req.session.loggedIn) {
        res.redirect('/')
    } else
        res.render('users/signin', { "logError": req.session.loginErr })
    req.session.loginErr = false
})
router.get('/signup', (req, res, next) => {
    res.render('users/signup')
})
router.post('/signup', (req, res, next) => {
    userHelper.doSignup(req.body).then((response) => {
        req.session.loggedIn = true
        req.session.user = response
        res.redirect('/')
    })
})
router.post('/signin', (req, res, next) => {
    userHelper.doSignin(req.body).then((response) => {
        if (response.status) {
            req.session.loggedIn = true
            req.session.user = response.user
            res.redirect('/')
        } else {
            req.session.loginErr = true
            res.redirect('/signin')
        }
    })
})
router.get('/logout', (req, res, next) => {
    req.session.destroy()
    res.redirect('/')
})
router.get('/add-cart/:id', verifyLogin, (req, res, next) => {
    userHelper.addtoCart(req.params.id, req.session.user._id).then(() => {
        res.json({ status: true })
    })
})
router.get('/cart', verifyLogin, async (req, res, next) => {
    let user = req.session.user
    let cartCount = null
    if (user) {
        cartCount = await userHelper.getCartCount(req.session.user._id)
    }
    const products= await userHelper.getCartProduct(user._id)
    const total= await userHelper.getTotal(user._id)
    res.render('users/cart-products', { products, user: req.session.user, cartCount, total})

})
router.post('/change-quantity', (req, res, next) => {

    userHelper.changeQuantity(req.body).then(async (response) => {
        res.json(response)
    })
})
router.post('/delete-product', (req, res, next) => {

    userHelper.deleteProduct(req.body).then(async (response) => {
        res.json(response)
    })
})



module.exports = router;