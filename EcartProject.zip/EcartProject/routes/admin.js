var express = require('express');
var router = express.Router();
var productHelper = require('../helpers/product-helpers')

/* GET users listing. */
router.get('/', function(req, res, next) {
    productHelper.getAllProducts().then((products) => {
        res.render('admin/view-products', { admin: true, products });
    })

});
router.get('/add-product', function(req, res, next) {
    res.render('admin/add-product', { admin: true });
});

router.post('/add-product', (req, res, next) => {
    productHelper.addProduct(req.body, (id) => {
        
        var image = req.files.images
        image.mv('./public/product-images/' + id + '.jpg', (err, done) => {
            if (!err) {
                productHelper.addStatus(id).then((response) => {
                    res.redirect('/admin/add-product')
                })
            } else {
                console.log("Error Occured " + err)
            }
        })
    })
});

router.get('/delete-product/:id', (req, res, next) => {
    let productId = req.params.id;
    productHelper.deleteProduct(productId).then((response) => {
        res.redirect('/admin')
    })
});
router.get('/edit-product/:id', async(req, res, next) => {
    let product = await productHelper.getProductDetails(req.params.id)
    res.render('admin/edit-product', { product })
});
router.post('/edit-product/:id', (req, res, next) => {
    productHelper.updateProduct(req.params.id, req.body).then(() => {
        res.redirect('/admin')
        let id = req.params.id
        if (req.files.images) {
            var image = req.files.images
            image.mv('./public/product-images/' + id + '.jpg')
        }

    })
});

module.exports = router;