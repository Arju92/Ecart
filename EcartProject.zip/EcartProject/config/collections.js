module.exports={
    PRODUCT_COLLECTIONS:'product',
    USER_COLLECTIONS:'user',
    CART_COLLECTIONS:'cart'
}